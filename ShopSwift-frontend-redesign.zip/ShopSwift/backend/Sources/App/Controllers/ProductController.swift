import Fluent
import Vapor

/// Public catalog endpoints. REST is ideal here because these are request/response resources.
struct ProductController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let products = routes.grouped("api", "v1", "products")
        products.get(use: index)
        products.get(":productID", use: show)

        routes.get("api", "v1", "categories", use: categories)
    }

    func index(req: Request) async throws -> [ProductResponse] {
        var query = Product.query(on: req.db)

        if let category: String = req.query["category"], !category.isEmpty {
            query = query.filter(\.$category == category)
        }

        // Fluent's contains filter provides a small catalog search without a separate search service.
        if let rawSearch: String = req.query["q"],
           !rawSearch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let search = rawSearch.trimmingCharacters(in: .whitespacesAndNewlines)
            query = query.filter(\.$name ~~ search)
        }

        let products = try await query.sort(\.$name).all()
        return try products.map(ProductResponse.init(product:))
    }

    func show(req: Request) async throws -> ProductResponse {
        guard let id = req.parameters.get("productID", as: UUID.self),
              let product = try await Product.find(id, on: req.db) else {
            throw Abort(.notFound, reason: "Product not found.")
        }
        return try ProductResponse(product: product)
    }

    func categories(req: Request) async throws -> [String] {
        // This stays database-driven: adding a product category automatically makes it navigable.
        let products = try await Product.query(on: req.db).sort(\.$category).all()
        return Array(Set(products.map(\.category))).sorted()
    }
}
